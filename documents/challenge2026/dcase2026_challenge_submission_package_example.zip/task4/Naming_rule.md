Naming rule for the output (there will also be a bash script that creates the zip file for submission)
The source index is used solely to distinguish sources within a mixture and does not affect the evaluation results.

|
└───[Author]_[Affiliation]_task4_[Submission number]_out.zip
│   └───[Author]_[Affiliation]_task4_[Submission number]_out
│   │   ├───eval_out
│   │   │   ├───eval_0000_[SourceIndex 0]_[EventClass1].wav
│   │   │   ├───eval_0000_[SourceIndex 1]_[EventClass2].wav
│   │   │   ├───eval_0001_[SourceIndex 0]_[EventClass1].wav
│   │   │   └───...
│   │   ├───eval_results.json
│   │   └───dev_set_test_results.json
