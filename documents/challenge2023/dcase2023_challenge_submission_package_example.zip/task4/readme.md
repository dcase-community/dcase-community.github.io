Participants are allowed to submit up to 4 different systems without ensembling and 4 systems with ensembling. Participants **have to submit at least one system without ensembling** . Each participants is expected to submit **at least one system without external data**. Participants using external data/pretrained models, please make sure to fill the field corresponding to the field in the yaml file.

For each submission, participants should provide the outputs obtained with 3 differents runs of the same systems in order to compute confidence intervals.

**Before submission, please make sure you check that your submission package is correct with the validation script enclosed:**
`python validate_submissions.py -i /Users/nturpaul/Documents/code/dcase2020/task4_test`
