**Only the csv files formatted as `Wisdom_INR_task4_SS_1.output.tsv` and `Wisdom_INR_task4_SS_1.ssmetrics.csv` are mandatory to participate.**

The ss metric file (similar to `Wisdom_INR_task4_SS_1.ssmetrics.csv`) can be obtained from  https://github.com/google-research/sound-separation/blob/master/models/dcase2020_fuss_baseline/evaluate.py.

PSDS submissions are optional. If you want your system to be evaluated in PSDS please follow strictly the format illustrated in `Wisdom_task4_SS_1.output_PSDS`. In order to comply with the submission platform restrictions, you will need to upload these in separate archive files.

If you experience any problem while submitting PSDS outputs please contact the task organizers (Romain Serizel in priority).
