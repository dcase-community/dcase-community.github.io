As we encourage participants to use a source separation algorithm together with the sound event detection, there are three possible scenarios:

1. You are working sound event detection without source separation pre-processing (see folder `Turpault_INR_task4_SED_1`)
2. You are are working on both source separation and sound event detection (see folder `Turpault_INR_task4_SS_SED_1`)
3. You are working only on source separation and use the sound event detection baseline (folder `Wisdom_GOO_task_4_SS_1`)

Participants are allowed to submit up to 4 different systems for each scenario listed above. **In each case, participants are expected to provide at least the output of a sound event detection system (see also the readme.md files in the corresponding subfolder.)**

For each scenario please recreate a new folder as illustrated here mentioning in the folder name:

* `SED` for scenario 1
* `SS_SED` for scenario 2
* `SS` for scenario 3

**Before submission, please make sure you check that your submission package is correct with the validation script enclosed:**
`python validate_submissions.py -i /Users/nturpaul/Documents/code/dcase2020/task4_test`
