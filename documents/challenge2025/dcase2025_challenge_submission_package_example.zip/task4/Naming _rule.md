Naming rule for the output (there will also be a bash script that creates the zip file for submission)

|
└───[Author]_[Affiliation]_task4_[Submission number]_out.zip
│   └───[Author]_[Affiliation]_task4_[Submission number]_out
│   │   └───eval_out
│   │   │       eval_0000_[EventClass1].wav
│   │   │       eval_0000_[EventClass2].wav
│   │   │       eval_0001_[EventClass1].wav
│   │   : 		
