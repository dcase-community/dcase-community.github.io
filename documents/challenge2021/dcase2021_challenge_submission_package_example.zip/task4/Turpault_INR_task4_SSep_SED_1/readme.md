Please follow strictly the format illustrated in `Turpault_INR_task4_SED_1.output_PSDS` directory. In order to comply with the submission platform restrictions, you will need to upload these in separate archive files.

If you experience any problem while submitting PSDS outputs please contact the task organizers (Romain Serizel in priority).

If you want your system to be evaluated in terms of SSep metrics as well please submit a file formatted as `Turpault_INR_task4_SSep_SED_1.SSepmetrics.csv` that can be obtained from  https://github.com/google-research/sound-separation/blob/master/models/dcase2020_fuss_baseline/evaluate.py.
