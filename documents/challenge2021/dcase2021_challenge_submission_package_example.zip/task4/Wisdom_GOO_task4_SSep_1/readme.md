Please follow strictly the format illustrated in `Turpault_INR_task4_SED_1.output_PSDS` directories. In order to comply with the submission platform restrictions, you will need to upload these in separate archive files.

If you experience any problem while submitting PSDS outputs please contact the task organizers (Romain Serizel in priority).

The SSep metric file (similar to `Wisdom_INR_task4_SS_1.SSepmetrics.csv`) can be obtained from  https://github.com/google-research/sound-separation/blob/master/models/dcase2020_fuss_baseline/evaluate.py.
